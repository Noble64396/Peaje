const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const { getAllVideos, createVideo, deleteVideo } = require('../controllers/videosController');
const auth = require('../middleware/auth');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.resolve(__dirname, '../uploads/videos/')),
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'video-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const videoFilter = (req, file, cb) => {
    if (file.mimetype.startsWith('video')) {
        cb(null, true);
    } else {
        cb(new Error('Formato de archivo no soportado, solo se aceptan videos.'), false);
    }
};

const upload = multer({ storage: storage, fileFilter: videoFilter });

router.get('/', getAllVideos);
router.post('/', [auth, upload.single('video')], createVideo);
router.delete('/:id', auth, deleteVideo);

module.exports = router;