const express = require('express');
const router = express.Router();
// 1. Importamos la nueva función y el middleware de autenticación
const { createUsuario, createUserByAdmin, loginUsuario } = require('../controllers/usuariosController');
const auth = require('../middleware/auth');

// --- RUTAS PÚBLICAS ---
// Ruta para que CUALQUIERA se registre (obtendrá el rol 'supervisor' por defecto)
router.post('/register', createUsuario);

// Ruta para que CUALQUIERA inicie sesión
router.post('/login', loginUsuario);


// --- RUTA PRIVADA PARA ADMINISTRADORES ---
// Ruta para que un ADMIN cree un nuevo usuario con un rol específico
router.post('/', auth(['admin']), createUserByAdmin);


module.exports = router;