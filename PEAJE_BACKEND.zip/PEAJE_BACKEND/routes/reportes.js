const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const { getAllReportes, createReporte, deleteReporte } = require('../controllers/reportesController');

// --- Configuración de Multer (ESTA PARTE ES LA QUE FALTA O ESTÁ INCORRECTA) ---
// Define dónde y cómo se guardarán los archivos subidos.
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    // Se guardarán en la carpeta 'uploads' en la raíz del backend.
    cb(null, path.resolve(__dirname, '../uploads/publicaciones/'));
  },
  filename: (req, file, cb) => {
    // Se genera un nombre único para cada archivo para evitar sobreescrituras.
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

// Se crea la variable 'upload' que se usará como middleware en la ruta POST.
const upload = multer({ storage: storage });


// --- Rutas ---
router.get('/', getAllReportes);

// La variable 'upload' ya está definida y se puede usar aquí.
router.post('/', upload.single('imagen'), createReporte);

router.delete('/:id', deleteReporte);

module.exports = router;