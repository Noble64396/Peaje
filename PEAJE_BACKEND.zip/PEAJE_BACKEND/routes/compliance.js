const express = require('express');
const router = express.Router();
const { getComplianceLogs, createComplianceLog } = require('../controllers/complianceController');
const auth = require('../middleware/auth');

// Ambas rutas son protegidas, solo usuarios logueados pueden acceder
// Ver registros: admins y supervisores
router.get('/', auth(['admin', 'supervisor']), getComplianceLogs);

// Crear un nuevo registro: solo admins
router.post('/', auth(['admin']), createComplianceLog);

module.exports = router;