const express = require('express');
const router = express.Router();
const { updateAniPassword } = require('../controllers/settingsController');
const auth = require('../middleware/auth');

// Ruta protegida para que solo el admin pueda cambiar la contraseña
router.post('/ani-password', auth(['admin']), updateAniPassword);

module.exports = router;