const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const { getFolderContents, createItem,getAllArchivos, createArchivo, getProtectedArchivos, deleteArchivo } = require('../controllers/archivosController');
const auth = require('../middleware/auth');

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, path.resolve(__dirname, '../uploads/archivos/')),
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, 'archivo-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const fileFilter = (req, file, cb) => {
    const allowedTypes = ['application/pdf', 'application/vnd.ms-excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];
    if (allowedTypes.includes(file.mimetype)) {
        cb(null, true);
    } else {
        cb(new Error('Formato no soportado. Solo PDF y Excel.'), false);
    }
};

const upload = multer({ storage: storage, fileFilter: fileFilter });

// --- Rutas ---
router.get('/', getAllArchivos);
router.post('/protected', getProtectedArchivos); // Ruta para obtener archivos con contraseña
router.post('/', [auth(['admin']), upload.single('archivo')], createArchivo); // Ruta para subir archivos
router.delete('/:id', auth(['admin']), deleteArchivo);

module.exports = router;