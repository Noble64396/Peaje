const jwt = require('jsonwebtoken');

// Esta es la única función que necesitamos.
// Recibe un array de roles permitidos (ej: ['admin'])
const auth = (rolesPermitidos) => {
  return (req, res, next) => {
    const authHeader = req.header('Authorization');

    if (!authHeader) {
      return res.status(401).json({ msg: 'No hay token, permiso no válido' });
    }

    try {
      const token = authHeader.split(' ')[1];
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      
      req.user = decoded.user; // req.user ahora tiene id, email y rol

      // Verificamos si el rol del usuario está en la lista de roles permitidos
      if (rolesPermitidos && rolesPermitidos.includes(req.user.rol)) {
        next(); // El usuario tiene el rol correcto, puede continuar.
      } else {
        // El usuario está autenticado pero NO tiene permisos para esta ruta.
        res.status(403).json({ msg: 'Acceso prohibido: no tienes los permisos necesarios.' });
      }
    } catch (err) {
      res.status(401).json({ msg: 'Token no es válido' });
    }
  };
};

module.exports = auth;