const pool = require('../config/db');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');

// Para el formulario de registro PÚBLICO
const createUsuario = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ msg: 'Por favor, ingrese email y contraseña.' });
    }
    
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    // El rol por defecto será 'supervisor' según la configuración de la DB
    const nuevoUsuario = await pool.query(
      "INSERT INTO usuarios (email, password_hash) VALUES ($1, $2) RETURNING id, email, rol",
      [email, passwordHash]
    );

    res.status(201).json(nuevoUsuario.rows[0]);

  } catch (err) {
    if (err.code === '23505') {
        return res.status(400).json({ msg: 'El email ya se encuentra registrado.' });
    }
    console.error("Error en createUsuario:", err.message);
    res.status(500).send('Error en el servidor');
  }
};

// --- NUEVA FUNCIÓN: Crear usuario desde el panel de admin ---
const createUserByAdmin = async (req, res) => {
    try {
        const { email, password, rol } = req.body;
        if (!email || !password || !rol) {
            return res.status(400).json({ msg: 'Email, contraseña y rol son requeridos.' });
        }
        if (rol !== 'admin' && rol !== 'supervisor') {
            return res.status(400).json({ msg: 'Rol no válido.' });
        }

        const salt = await bcrypt.genSalt(10);
        const passwordHash = await bcrypt.hash(password, salt);

        const nuevoUsuario = await pool.query(
          "INSERT INTO usuarios (email, password_hash, rol) VALUES ($1, $2, $3) RETURNING id, email, rol",
          [email, passwordHash, rol]
        );
        
        res.status(201).json(nuevoUsuario.rows[0]);
    } catch (err) {
        if (err.code === '23505') {
            return res.status(400).json({ msg: 'El email ya se encuentra registrado.' });
        }
        console.error("Error en createUserByAdmin:", err.message);
        res.status(500).send('Error en el servidor');
    }
};


// --- FUNCIÓN PARA INICIAR SESIÓN (Corregida) ---
const loginUsuario = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({ msg: 'Por favor, ingrese email y contraseña.' });
    }

    const userQuery = await pool.query("SELECT * FROM usuarios WHERE email = $1", [email]);

    if (userQuery.rows.length === 0) {
      return res.status(400).json({ msg: 'Credenciales inválidas.' });
    }
    
    const user = userQuery.rows[0];

    const isMatch = await bcrypt.compare(password, user.password_hash);

    if (!isMatch) {
      return res.status(400).json({ msg: 'Credenciales inválidas.' });
    }

    const payload = {
      user: {
        id: user.id,
        email: user.email,
        rol: user.rol
      }
    };

    // Corregido: Solo una llamada a jwt.sign
    jwt.sign(
      payload,
      process.env.JWT_SECRET,
      { expiresIn: '5h' },
      (err, token) => {
        if (err) throw err;
        res.json({ token });
      }
    );

  } catch (err) {
    console.error("Error en loginUsuario:", err.message);
    res.status(500).send('Error en el servidor');
  }
};


module.exports = {
  createUsuario,
  createUserByAdmin, // Exportamos la nueva función
  loginUsuario,
};