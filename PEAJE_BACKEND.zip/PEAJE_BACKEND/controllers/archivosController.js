const pool = require('../config/db');
const fs = require('fs');
const path = require('path');
const bcrypt = require('bcrypt');

// Obtener solo archivos PÚBLICOS
const getAllArchivos = async (req, res) => {
  try {
    const { search } = req.query;
    let query = 'SELECT * FROM archivos WHERE is_protected = false ORDER BY created_at DESC';
    let queryParams = [];

    if (search) {
      query = 'SELECT * FROM archivos WHERE is_protected = false AND display_name ILIKE $1 ORDER BY created_at DESC';
      queryParams.push(`%${search}%`);
    }

    const result = await pool.query(query, queryParams);
    res.json(result.rows);
  } catch (err) {
    console.error("Error en getAllArchivos:", err.message);
    res.status(500).send('Error en el servidor');
  }
};

// --- OBTENER CONTENIDO DE UNA CARPETA ---
const getFolderContents = async (req, res) => {
  try {
    // El ID de la carpeta viene de la URL. Si no hay ID, es la carpeta raíz.
    const parentId = req.params.folderId || null;
    
    const query = 'SELECT * FROM archivos WHERE parent_id IS NOT DISTINCT FROM $1 ORDER BY item_type DESC, display_name ASC';
    const result = await pool.query(query, [parentId]);

    res.json(result.rows);
  } catch (err) {
    console.error("Error en getFolderContents:", err.message);
    res.status(500).send('Error en el servidor');
  }
};





// Subir un nuevo archivo (PÚBLICO O PROTEGIDO)
const createArchivo = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ msg: 'Se requiere un archivo.' });
    }
    if (!req.body.displayName) {
        return res.status(400).json({ msg: 'Se requiere un nombre para el archivo.' });
    }

    const { displayName, isProtected } = req.body;
    const filePath = `uploads/archivos/${req.file.filename}`;
    const fileType = req.file.mimetype;
    const isProtectedBool = (isProtected === 'true'); // Convertir string a booleano

    const newArchivo = await pool.query(
      "INSERT INTO archivos (display_name, file_path, file_type, is_protected) VALUES ($1, $2, $3, $4) RETURNING *",
      [displayName, filePath, fileType, isProtectedBool]
    );

    res.status(201).json(newArchivo.rows[0]);
  } catch (err) {
    console.error("Error en createArchivo:", err.message);
    res.status(500).send('Error en el servidor');
  }
};


// --- CREAR UN NUEVO ITEM (CARPETA O ARCHIVO) ---
const createItem = async (req, res) => {
    try {
        const { displayName, isProtected, itemType, parentId } = req.body;
        
        if (itemType === 'folder') {
            // --- Lógica para crear una CARPETA ---
            const newFolder = await pool.query(
              "INSERT INTO archivos (display_name, is_protected, item_type, parent_id) VALUES ($1, $2, 'folder', $3) RETURNING *",
              [displayName, isProtected === 'true', parentId || null]
            );
            return res.status(201).json(newFolder.rows[0]);
        }
        
        if (itemType === 'file') {
            // --- Lógica para subir un ARCHIVO ---
            if (!req.file) return res.status(400).json({ msg: 'Se requiere un archivo.' });

            const filePath = `uploads/archivos/${req.file.filename}`;
            const fileType = req.file.mimetype;

            const newFile = await pool.query(
              "INSERT INTO archivos (display_name, file_path, file_type, is_protected, item_type, parent_id) VALUES ($1, $2, $3, $4, 'file', $5) RETURNING *",
              [displayName, filePath, fileType, isProtected === 'true', parentId || null]
            );
            return res.status(201).json(newFile.rows[0]);
        }
        
        return res.status(400).json({ msg: 'Tipo de item no válido.' });
    } catch (err) {
        console.error("Error en createItem:", err.message);
        res.status(500).send('Error en el servidor');
    }
};


// Obtener archivos protegidos con contraseña
const getProtectedArchivos = async (req, res) => {
    try {
        const { password } = req.body;
        if (!password) {
            return res.status(400).json({ msg: 'Contraseña requerida.' });
        }

        const storedPasswordQuery = await pool.query("SELECT setting_value FROM settings WHERE setting_key = 'ani_password'");

        if (storedPasswordQuery.rows.length === 0) {
            return res.status(400).json({ msg: 'No se ha configurado una contraseña de ANI.' });
        }
        
        const hashedPassword = storedPasswordQuery.rows[0].setting_value;
        const isMatch = await bcrypt.compare(password, hashedPassword);

        if (!isMatch) {
            return res.status(401).json({ msg: 'Contraseña incorrecta.' });
        }

        const archivos = await pool.query("SELECT * FROM archivos WHERE is_protected = true ORDER BY created_at DESC");
        res.json(archivos.rows);
    } catch (err) {
        console.error("Error en getProtectedArchivos:", err.message);
        res.status(500).send('Error en el servidor');
    }
};

// Eliminar un archivo
const deleteArchivo = async (req, res) => {
    try {
        const { id } = req.params;
        const fileQuery = await pool.query("SELECT file_path FROM archivos WHERE id = $1", [id]);

        if (fileQuery.rows.length === 0) {
            return res.status(404).json({ msg: 'Archivo no encontrado.' });
        }
        
        await pool.query("DELETE FROM archivos WHERE id = $1", [id]);

        const filePath = fileQuery.rows[0].file_path;
        if (filePath) {
            const absolutePath = path.resolve(__dirname, '..', filePath);
            fs.unlink(absolutePath, (err) => {
                if (err) console.error("Error al eliminar el archivo físico:", err);
                else console.log("Archivo físico eliminado:", absolutePath);
            });
        }
        
        res.json({ msg: 'Archivo eliminado correctamente.' });
    } catch (err) {
        console.error("Error en deleteArchivo:", err.message);
        res.status(500).send('Error en el servidor');
    }
};

module.exports = { 
  getAllArchivos, 
  createArchivo, 
  getProtectedArchivos,
  deleteArchivo ,
  getFolderContents
};