const pool = require('../config/db');

// Obtener todos los registros de cumplimiento
const getComplianceLogs = async (req, res) => {
  try {
    // Unimos con la tabla de usuarios para saber quién hizo la verificación
    const query = `
      SELECT cl.id, cl.verification_date, cl.status, cl.notes, u.email as verified_by
      FROM compliance_log cl
      JOIN usuarios u ON cl.verified_by_user_id = u.id
      ORDER BY cl.verification_date DESC, cl.created_at DESC
    `;
    const result = await pool.query(query);
    res.json(result.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
};

// Crear un nuevo registro de cumplimiento
const createComplianceLog = async (req, res) => {
  try {
    const { verification_date, status, notes } = req.body;
    const verified_by_user_id = req.user.id; // Obtenido del token de autenticación

    if (!verification_date || !status) {
      return res.status(400).json({ msg: 'La fecha y el estado son requeridos.' });
    }

    const newLog = await pool.query(
      "INSERT INTO compliance_log (verification_date, status, notes, verified_by_user_id) VALUES ($1, $2, $3, $4) RETURNING *",
      [verification_date, status, notes, verified_by_user_id]
    );

    res.status(201).json(newLog.rows[0]);
  } catch (err) {
    console.error("Error en createComplianceLog:", err.message);
    res.status(500).send('Error en el servidor');
  }
};

module.exports = { getComplianceLogs, createComplianceLog };