const pool = require('../config/db');
const bcrypt = require('bcrypt');

const updateAniPassword = async (req, res) => {
  try {
    const { password } = req.body;
    if (!password || password.length < 6) {
      return res.status(400).json({ msg: 'La contraseña debe tener al menos 6 caracteres.' });
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    // Inserta o actualiza la contraseña si ya existe (UPSERT)
    const query = `
      INSERT INTO settings (setting_key, setting_value)
      VALUES ('ani_password', $1)
      ON CONFLICT (setting_key)
      DO UPDATE SET setting_value = EXCLUDED.setting_value;
    `;
    await pool.query(query, [passwordHash]);

    res.json({ msg: 'Contraseña de la ANI actualizada con éxito.' });
  } catch (err) {
    console.error("Error al actualizar contraseña:", err.message);
    res.status(500).send('Error en el servidor');
  }
};

module.exports = { updateAniPassword };