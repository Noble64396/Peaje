const pool = require('../config/db');
const fs = require('fs');
const path = require('path');

// --- OBTENER TODOS LOS REPORTES ---
const getAllReportes = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM reportes ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (err) {
    console.error("Error en getAllReportes:", err.message);
    res.status(500).send('Error en el servidor');
  }
};

// --- CREAR UN NUEVO REPORTE (LA FUNCIÓN QUE FALTABA) ---
const createReporte = async (req, res) => {
  try {
    // Validar que el archivo y los datos de texto existen
    if (!req.file || !req.body.data) {
      return res.status(400).json({ msg: 'Faltan datos. Se requiere una imagen y datos del reporte.' });
    }

    // Extraer los datos del cuerpo de la petición
    const { titulo, resumen } = JSON.parse(req.body.data); 
    const imageUrl = `uploads/publicaciones/${req.file.filename}`

    // Crear el objeto JSONB que se guardará en la base de datos
    const reporteData = { titulo, resumen };

    // Ejecutar la consulta SQL para insertar el nuevo reporte
    const nuevoReporte = await pool.query(
      "INSERT INTO reportes (data, image_url) VALUES ($1, $2) RETURNING *",
      [reporteData, imageUrl]
    );

    // Enviar la respuesta al frontend con el reporte creado
    res.status(201).json(nuevoReporte.rows[0]);

  } catch (err) {
    console.error("Error en createReporte:", err.message);
    res.status(500).send('Error en el servidor');
  }
};

// --- ELIMINAR UN REPORTE ---
const deleteReporte = async (req, res) => {
  try {
    const { id } = req.params;

    const imageQuery = await pool.query("SELECT image_url FROM reportes WHERE id = $1", [id]);

    if (imageQuery.rows.length === 0) {
      return res.status(404).json({ msg: 'Reporte no encontrado.' });
    }

    const imageUrl = imageQuery.rows[0].image_url;
    await pool.query("DELETE FROM reportes WHERE id = $1", [id]);

    if (imageUrl) {
      const imagePath = path.resolve(__dirname, '..', imageUrl);
      fs.unlink(imagePath, (err) => {
        if (err) {
          console.error("Error al eliminar el archivo de imagen:", err);
        } else {
          console.log("Archivo de imagen eliminado:", imagePath);
        }
      });
    }

    res.json({ msg: 'Reporte eliminado correctamente.' });

  } catch (err) {
    console.error("Error en deleteReporte:", err.message);
    res.status(500).send('Error en el servidor');
  }
};

module.exports = {
  getAllReportes,
  createReporte,
  deleteReporte,
};