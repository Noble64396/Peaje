const pool = require('../config/db');
const fs = require('fs');
const path = require('path');

const getAllVideos = async (req, res) => {
  try {
    const result = await pool.query('SELECT * FROM videos ORDER BY created_at DESC');
    res.json(result.rows);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Error en el servidor');
  }
};

const createVideo = async (req, res) => {
  try {
    const { title, description, video_type, youtube_embed_id } = JSON.parse(req.body.data);
    let videoSource;

    if (video_type === 'youtube') {
      if (!youtube_embed_id) {
        return res.status(400).json({ msg: 'Se requiere ID de YouTube para este tipo de video.' });
      }
      videoSource = youtube_embed_id;
    } else if (video_type === 'local') {
      if (!req.file) {
        return res.status(400).json({ msg: 'Se requiere un archivo para este tipo de video.' });
      }
      videoSource = `uploads/videos/${req.file.filename}`;
    } else {
      return res.status(400).json({ msg: 'Tipo de video no válido.' });
    }

    const newVideo = await pool.query(
      "INSERT INTO videos (title, description, video_source, video_type) VALUES ($1, $2, $3, $4) RETURNING *",
      [title, description, videoSource, video_type]
    );

    res.status(201).json(newVideo.rows[0]);
  } catch (err) {
    console.error("Error en createVideo:", err.message);
    res.status(500).send('Error en el servidor');
  }
};

const deleteVideo = async (req, res) => {
    try {
        const { id } = req.params;
        const videoQuery = await pool.query("SELECT video_source, video_type FROM videos WHERE id = $1", [id]);

        if (videoQuery.rows.length === 0) {
            return res.status(404).json({ msg: 'Video no encontrado.' });
        }
        
        const { video_source, video_type } = videoQuery.rows[0];
        
        await pool.query("DELETE FROM videos WHERE id = $1", [id]);

        if (video_type === 'local' && video_source) {
            const videoPath = path.resolve(__dirname, '..', video_source);
            fs.unlink(videoPath, (err) => {
                if (err) console.error("Error al eliminar el archivo de video:", err);
                else console.log("Archivo de video eliminado:", videoPath);
            });
        }
        
        res.json({ msg: 'Video eliminado correctamente.' });
    } catch (err) {
        console.error("Error en deleteVideo:", err.message);
        res.status(500).send('Error en el servidor');
    }
};

module.exports = {
  getAllVideos,
  createVideo,
  deleteVideo,
};