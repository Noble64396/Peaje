// Carga las variables de entorno desde el archivo .env
require('dotenv').config();

// 1. IMPORTACIONES
// -----------------
const express = require('express');
const cors = require('cors');
const path = require('path');
const createTables = require('./config/initDb'); // Script para crear tablas en la DB
const reportesRoutes = require('./routes/reportes'); // Rutas para los reportes
const usuariosRoutes = require('./routes/usuarios'); // Rutas para los usuarios
const videosRoutes = require('./routes/videos'); // <-- 1. Importa las nuevas rutas
const archivosRoutes = require('./routes/archivos'); // <-- 1. Importa
const createUploadsFolders = require('./config/createUploadsFolders'); // <-- 1. Importa el nuevo script
const complianceRoutes = require('./routes/compliance'); // <-- 1. Importa
const settingsRoutes = require('./routes/settings'); // <-- 1. IMPORTA LAS NUEVAS RUTAS


// 2. INICIALIZACIÓN
// ------------------
const app = express();
const port = process.env.PORT || 5000;

// 3. MIDDLEWARES (Funciones que se ejecutan en cada petición)
// ------------------------------------------------------------

// ✅ SÍ, AQUÍ ESTÁ CORS: Habilita Cross-Origin Resource Sharing.
// Esto permite que tu frontend en 168.231.70.54:3000 pueda hacer peticiones a tu backend en 168.231.70.54:5000.
app.use(cors());

// Permite que el servidor entienda y procese datos en formato JSON.
app.use(express.json()); 

// Permite que los archivos subidos en la carpeta 'uploads' sean accesibles desde el navegador.
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// 4. RUTAS PRINCIPALES (Asigna las rutas a sus manejadores)
// ------------------------------------------------------------
app.use('/api/reportes', reportesRoutes);
app.use('/api/usuarios', usuariosRoutes);
app.use('/api/videos', videosRoutes); // <-- 2. Usa las nuevas rutas
app.use('/api/archivos', archivosRoutes); // <-- 2. Usa las nuevas rutas
// ... (otras rutas)
app.use('/api/compliance', complianceRoutes); // <-- 2. Usa las nuevas rutas
app.use('/api/settings', settingsRoutes); // <-- 2. USA LAS NUEVAS RUTAS


// 5. FUNCIÓN DE ARRANQUE (Asegura que la DB esté lista antes de iniciar)
// -----------------------------------------------------------------------
const startServer = async () => {
  try {
    createUploadsFolders(); // <-- 2. Ejecútalo antes de crear las tablas
    await createTables();

    // Una vez confirmado, inicia el servidor Express
    app.listen(port, () => {
      console.log(`🚀 Servidor corriendo en http://168.231.70.54:${port}`);
    });
  } catch (err) {
    console.error('❌ Falló el inicio del servidor:', err);
    process.exit(1);
  }
};

// Se llama a la función para que todo el proceso comience
startServer();