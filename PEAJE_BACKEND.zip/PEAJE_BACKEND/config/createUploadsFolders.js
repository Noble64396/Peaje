const fs = require('fs');
const path = require('path');

const createUploadsFolders = () => {
  const uploadsDir = path.resolve(__dirname, '../uploads');
  const subfolders = ['publicaciones', 'videos', 'archivos'];

  try {
    // Asegurarse de que el directorio principal 'uploads' exista
    if (!fs.existsSync(uploadsDir)) {
      fs.mkdirSync(uploadsDir);
    }

    // Crear cada subdirectorio
    subfolders.forEach(folder => {
      const folderPath = path.join(uploadsDir, folder);
      if (!fs.existsSync(folderPath)) {
        fs.mkdirSync(folderPath);
        console.log(`📁 Carpeta creada: ${folderPath}`);
      }
    });
  } catch (err) {
    console.error('❌ Error al crear las carpetas de subida:', err);
    process.exit(1);
  }
};

module.exports = createUploadsFolders;