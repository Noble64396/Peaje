const pool = require('./db');

const createTables = async () => {
const createUsuariosTableQuery = `
  CREATE TABLE IF NOT EXISTS usuarios (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    rol VARCHAR(50) NOT NULL DEFAULT 'supervisor', -- <-- AÑADIDO
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
  );
`;
  const createReportesTableQuery = `
    CREATE TABLE IF NOT EXISTS reportes (
      id SERIAL PRIMARY KEY,
      data JSONB NOT NULL,
      image_url VARCHAR(255),
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );
  `;
  const createVideosTableQuery = `
    CREATE TABLE IF NOT EXISTS videos (
      id SERIAL PRIMARY KEY,
      title VARCHAR(255) NOT NULL,
      description TEXT,
      video_source VARCHAR(255),
      video_type VARCHAR(10) NOT NULL DEFAULT 'local',
      created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
    );
  `;

  // --- NUEVA QUERY PARA LA TABLA DE ARCHIVOS ---
const createArchivosTableQuery = `
  CREATE TABLE IF NOT EXISTS archivos (
    id SERIAL PRIMARY KEY,
    display_name VARCHAR(255) NOT NULL,
    file_path VARCHAR(255) NOT NULL,
    file_type VARCHAR(50) NOT NULL,
    is_protected BOOLEAN NOT NULL DEFAULT false, -- <-- AÑADIDO
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
  );
`;

const createSettingsTableQuery = `
  CREATE TABLE IF NOT EXISTS settings (
    setting_key VARCHAR(100) PRIMARY KEY,
    setting_value VARCHAR(255) NOT NULL
  );
`;

  

const createComplianceLogTableQuery = `
  CREATE TABLE IF NOT EXISTS compliance_log (
    id SERIAL PRIMARY KEY,
    verification_date DATE NOT NULL,
    status VARCHAR(50) NOT NULL CHECK (status IN ('Conforme', 'No Conforme', 'Con Observaciones')),
    notes TEXT,
    verified_by_user_id INTEGER REFERENCES usuarios(id),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
  );
`;

  try {
    await pool.query(createUsuariosTableQuery);
    await pool.query(createReportesTableQuery);
    await pool.query(createVideosTableQuery);
    await pool.query(createArchivosTableQuery);
    await pool.query(createComplianceLogTableQuery); // <-- Ejecuta la nueva query
    await pool.query(createSettingsTableQuery); // <-- Ejecuta la nueva query

    console.log('✅ Tablas verificadas y/o creadas correctamente en la base de datos.');
  } catch (err) {
    console.error('❌ Error al intentar crear las tablas:', err);
    process.exit(1);
  }
};

module.exports = createTables;